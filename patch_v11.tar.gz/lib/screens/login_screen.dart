import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';
import 'main_shell.dart';
import 'student_auth_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 36,
                    backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                    child: Icon(
                      Icons.computer_rounded,
                      size: 38,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'Aula Fácil',
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Seu diário de classe digital',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  const SizedBox(height: 28),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'E-mail',
                      prefixIcon: Icon(Icons.mail_outline),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Senha',
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: busy || !app.auth.firebaseReady ? null : _signIn,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(busy ? 'Entrando...' : 'ENTRAR'),
                      ),
                    ),
                  ),
                  if (app.auth.firebaseReady) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton(
                          onPressed: _resetPassword,
                          child: const Text('Esqueci minha senha'),
                        ),
                        TextButton(
                          onPressed: _register,
                          child: const Text('Criar conta'),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 4),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: app.auth.firebaseReady
                          ? () => Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const StudentAuthScreen()),
                              )
                          : null,
                      icon: const Icon(Icons.school_outlined),
                      label: const Text('SOU ALUNO'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Text(
                          app.auth.firebaseReady
                              ? 'Também é possível usar o aplicativo apenas neste aparelho, sem sincronização em nuvem.'
                              : 'Firebase ainda não configurado. O modo local está disponível e os dados ficam salvos no aparelho.',
                        ),
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: _enterLocal,
                          child: const Text('ENTRAR NO MODO LOCAL'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _signIn() async {
    setState(() => busy = true);
    final app = context.read<AppController>();
    final error = await app.auth.signIn(email.text.trim(), password.text);
    if (!mounted) return;
    setState(() => busy = false);
    if (error == null) {
      final role = await app.auth.currentRole();
      if (!mounted) return;
      if (role != 'teacher') {
        await app.auth.signOut();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Esta conta está cadastrada como aluno. Use “SOU ALUNO”.')),
        );
        return;
      }
      await app.sync();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _register() async {
    setState(() => busy = true);
    final app = context.read<AppController>();
    final error = await app.auth.register(
      email.text.trim(),
      password.text,
      name: app.teacherName,
      role: 'teacher',
    );
    if (!mounted) return;
    setState(() => busy = false);
    if (error == null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _resetPassword() async {
    final error = await context.read<AppController>().auth.reset(email.text.trim());
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(error ?? 'E-mail de recuperação enviado.'),
      ),
    );
  }

  void _enterLocal() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }
}
