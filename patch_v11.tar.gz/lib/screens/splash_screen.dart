import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';
import 'login_screen.dart';
import 'main_shell.dart';
import 'student_home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool navigated = false;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    if (!app.loading && !navigated) {
      navigated = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _navigate(app));
    }
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircleAvatar(radius: 42, child: Icon(Icons.computer_rounded, size: 44)),
            const SizedBox(height: 16),
            Text('Aula Fácil', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }

  Future<void> _navigate(AppController app) async {
    if (!mounted) return;
    Widget target;
    if (app.auth.user == null) {
      target = const LoginScreen();
    } else {
      final role = await app.auth.currentRole();
      target = role == 'student' ? const StudentHomeScreen() : const MainShell();
    }
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => target));
  }
}
